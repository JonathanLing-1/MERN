import React from 'react'

const Number = props => {


    return (
        <div>
            <p>This is the number {props.num}</p>
        </div>
    )
}

export default Number
