import React from 'react'

const Hello = props => {
    return (
        <div>
            <p>The word is: {props.word}</p>
        </div>
    )
}

export default Hello
